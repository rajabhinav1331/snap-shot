import React from 'react'

import Search from './Search'
import foodicon from '../assets/food.jpg'
import '../styles/Food.css'

const Foods = () => {
  return (
   <>
         <Search />
    <h3>Food Photos</h3>
    <div className='food-container'>
     <img src={foodicon} alt=''/>
     <img src={foodicon} alt=''/>
     <img src={foodicon} alt=''/>
     <img src={foodicon} alt=''/>
     <img src={foodicon} alt=''/>
     <img src={foodicon} alt=''/>
     <img src={foodicon} alt=''/>
     <img src={foodicon} alt=''/>
     <img src={foodicon} alt=''/> 
     <img src={foodicon} alt=''/>
</div>
   </>
  )
}

export default Foods