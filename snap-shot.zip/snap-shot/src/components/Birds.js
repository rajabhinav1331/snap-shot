import React from 'react'
import birdspic from '../assets/birds.jpg'
import Search from './Search'
import '../styles/Birds.css'

export const Birds = () => {
  return (
    <>
    <Search />
    <h3>Birds Photos</h3>
    <div className='birds-container'>
     <img src={birdspic} alt=''/>
     <img src={birdspic} alt=''/>
     <img src={birdspic} alt=''/>
     <img src={birdspic} alt=''/>
     <img src={birdspic} alt=''/>
     <img src={birdspic} alt=''/>
     <img src={birdspic} alt=''/>
     <img src={birdspic} alt=''/>
     <img src={birdspic} alt=''/> 
     <img src={birdspic} alt=''/>
</div>

 
 </>

    
  )
}
