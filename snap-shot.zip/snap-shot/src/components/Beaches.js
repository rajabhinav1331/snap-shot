import React from 'react'
import Search from './Search'
import beach from '../assets/beaches.jpg'
import '../styles/Beaches.css'

export const Beaches = () => {
  return (
   <>
      <Search />
    <h3>Beaches Photos</h3>
    <div className='beaches-container'>
     <img src={beach} alt=''/>
     <img src={beach} alt=''/>
     <img src={beach} alt=''/>
     <img src={beach} alt=''/>
     <img src={beach} alt=''/>
     <img src={beach} alt=''/>
     <img src={beach} alt=''/>
     <img src={beach} alt=''/>
     <img src={beach} alt=''/> 
     <img src={beach} alt=''/>
</div>
   
   </>
  )
}
