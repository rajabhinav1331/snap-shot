import React from 'react'
import Search from './Search'
import moun from '../assets/mountain.jpg'
import '../styles/Mountain.css'

const Mountain = () => {
  return (
    <>
       <Search />
       <h3>Mountain Photos</h3>
       <div className='mountain-container'>
        <img src={moun} alt=''/>
        <img src={moun} alt=''/>
        <img src={moun} alt=''/>
        <img src={moun} alt=''/>
        <img src={moun} alt=''/>
        <img src={moun} alt=''/>
        <img src={moun} alt=''/>
        <img src={moun} alt=''/>
        <img src={moun} alt=''/> 
        <img src={moun} alt=''/>
   </div>

    
    </>
  
  )
}

export default Mountain