import React from 'react'
import "../styles/Search.css"
import { Link } from 'react-router-dom'
import ser from '../assets/search-black.jpg'

const Search = () => {
  return (
    <div>
      <div className='heading-container' id='font'>Snap-shot</div>
        <div className='search-box'>
            <input  placeholder='search' id='input-box' type='text'/>
            <img id='search-icon' src={ser} alt=''/>
        </div>
        <div className='button-container'>
            <Link to='/'><button className='search-btn'>Mountain</button></Link>
            <Link to='/birds'><button className='search-btn'>Birds</button></Link>
            <Link to='/beaches'><button className='search-btn'>Beaches</button></Link>
            <Link to='/food'><button className='search-btn'>Foods</button></Link>
          

       </div>
    </div>
  )
}

export default Search