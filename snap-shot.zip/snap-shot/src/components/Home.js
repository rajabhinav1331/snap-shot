// import React from 'react'
// import "../styles/Home.css"
// import Mountain from './Mountain'

// const Home = () => {
//   return (
//     <div>
//        <Mountain/>
        
//     </div>
//   )
// }

// export default Home