import {BrowserRouter, Routes, Route} from "react-router-dom";
import './App.css';
// import Home from './components/Home';
import Mountain from "./components/Mountain";
import { Birds } from "./components/Birds";
import { Beaches } from "./components/Beaches";
import Foods from "./components/Foods";


function App() {
  return (
    <BrowserRouter>
    <Routes>
      {/* <Route path="/" element={ <Home />} /> */}
      <Route path="/food" element={<Foods/> } />
      <Route path="/birds" element={ <Birds />} />
      <Route path="/" element={ <Mountain/>} />
      <Route path="/beaches" element={ <Beaches />} />
    </Routes>
    </BrowserRouter>
    
  
  
  );
}

export default App;
