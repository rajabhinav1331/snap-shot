import axiox from 'axios'

const Params = {
    Headers: {
       Authorization: 'bearer' + Process.env.FLICKER_APP_KEY ,
    },
};



export const fetchDataFromApi = async (url) =>{
    try {
        const { data } = await axiox.get(
            process.env.REACT_APP_DEV_URL + url,
            Params
        );
        return data;
    } catch (error) {
        console.log(error);
        return error;
    }
};